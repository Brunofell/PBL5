public class Animal {
     public void FazerBarulho(){
         System.out.println("BARULHO");
     }
}

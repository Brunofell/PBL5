public class Gato extends Animal {

    @Override
    public void FazerBarulho(){
        System.out.println("miau");
    }

}

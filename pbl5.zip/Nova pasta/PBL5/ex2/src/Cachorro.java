public class Cachorro extends Animal {

    @Override
    public void FazerBarulho(){
        System.out.println("AUAUAAUAUAUAAUAUAAUAUAUAAUAUAUA");
    }
}

public class Main {
    public static void main(String[] args) {
        Carro c1 = new Carro(50);
        Moto m1 = new Moto(100);


        c1.acelerar(50);
        m1.acelerar(50);
    }
}
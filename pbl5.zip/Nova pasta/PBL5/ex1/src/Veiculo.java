public abstract class Veiculo {

    public int acelerar(int a){
        return 0;
    }
}
